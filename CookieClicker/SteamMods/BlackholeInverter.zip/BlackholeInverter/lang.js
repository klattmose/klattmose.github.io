ModLanguage('EN',{
	
	"%1 black hole inverter": [
		"%1 black hole inverter",
		"%1 black hole inverters"
	],
	
});