ModLanguage('EN',{
	
	"%1 black hole inverter": [
		"%1 black hole inverter",
		"%1 black hole inverters"
	],
	"[Black hole inverter quote]Inverts the flow of gravity to get the infinitely delicious cookies from an infinitely dense singularity.": "Inverts the flow of gravity to get the infinitely delicious cookies from an infinitely dense singularity.",
	"[Black hole inverter business name]Hypnodrone": "Hypnodrone",
	'[Black hole inverter business quote]Autonomous aerial brand ambassadors to "encourage" more sales!': 'Autonomous aerial brand ambassadors to "encourage" more sales!',
	
});