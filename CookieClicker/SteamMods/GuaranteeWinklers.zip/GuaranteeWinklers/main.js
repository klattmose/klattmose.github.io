Game.registerMod("Guarantee Winklers",{
	init:function(){
		Game.WINKLERS = 1;
	}
});