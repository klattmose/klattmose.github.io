Game.registerMod("Steam Achievement Enabler",{
	init:function(){
		Steam.allowSteamAchievs = true;
	}
});